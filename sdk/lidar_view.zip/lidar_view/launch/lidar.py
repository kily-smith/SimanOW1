from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_name = 'lidar_view'
    return LaunchDescription([
        Node(
            package='lidar_view',
            namespace='lidar_view',
            executable='Lidar_MainNode',
            name='Lidar_MainNode',
            
            # LidarType 雷达型号
            #   LT_OW1               :21
            parameters=[{
                'LidarType': 21, # 雷达型号
                'ConnectType': 'on-line', # 连接模式:仅支持"on-line"、"off-line"两种模式配置
                'PcapFilePath': '/home/1.pcap', # 回放模式下配置: PCAP文件绝对路径
                'topic': "/tanwaylidar_pointcloud",
                'imu_topic': "/lidar_imu",
                'LocalHost': "192.168.111.204",
                'LocalPointloudPort': 5600,
                'LocalDIFPort': 5700,
                'LocalIMUPort': 5700,
                'LidarHost': "192.168.111.51",
                'AlgoTablePath': os.path.join(get_package_share_directory(pkg_name), 'config', "algo_table.json"),

                
                # Set the lidar core horizontal angle offset(Only support Scope series and Duetto). 
                'CoreHorAngleOffsetL': 0.0,
                'CoreHorAngleOffsetR': 0.0,

                # Set the lidar core vertical angle offset(Only support Scope series and Duetto).
                'CoreVerAngleOffsetL': 0.0,
                'CoreVerAngleOffsetR': 0.0,
                
                # Set the lidar mirror abc vertical angle offset.
                'MirrorVerAngleOffsetA': 0.0,
                'MirrorVerAngleOffsetB': 0.0,
                'MirrorVerAngleOffsetC': 0.0,

                # Set the lidar mirror abc horizontal angle offset.
                'MirrorHorAngleOffsetA': 0.0,
                'MirrorHorAngleOffsetB': 0.0,
                'MirrorHorAngleOffsetC': 0.0,

                # 帧时间戳
                'FrameTimeStampType': "last_point",
                'UseLidarClock': True,
                'CycleCountFrameSplit': False,

                # 时间分帧模式True、扫描分帧模式False
                'UseTimeWindow': False
                }],
            output='screen'
        ),
        Node(
            package='rviz2',
            namespace='',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', [os.path.join(get_package_share_directory(pkg_name), 'rviz', "show.rviz")]]
        ),
    ])
